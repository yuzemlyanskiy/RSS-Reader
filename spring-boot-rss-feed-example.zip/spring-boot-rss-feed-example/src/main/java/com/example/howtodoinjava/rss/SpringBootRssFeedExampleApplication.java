package com.example.howtodoinjava.rss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRssFeedExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRssFeedExampleApplication.class, args);
	}
}
